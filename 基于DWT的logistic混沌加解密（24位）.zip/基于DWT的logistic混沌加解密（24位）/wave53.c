long height,width;
int DWT[1024*1024],IDWT[1024*1024];
//С���任

void wv1d(int s[],int ys)
{
	long j;
	int d1[500],s1[500];          
		for(j=0;j<ys/2-1;j++)                                   //0-126,254...
		    d1[j]=s[2*j+1]-((s[2*j]+s[2*j+2])/2);               //��Ƶϵ��
			d1[ys/2-1]=s[ys-1]-s[ys-2];           //��Եƽ������127,255...
			s1[0]=s[0]+((d1[0]+d1[0])/4);                       //��Եƽ������0          
			for(j=1;j<ys/2;j++)
				s1[j]=s[2*j]+((d1[j-1]+d1[j])/4);               //��Ƶϵ��1-127,255
			for(j=0;j<ys/2;j++){      
				s[j]=s1[j];                                     //�ȴ����Ƶϵ��
				s[j+ys/2]=d1[j];                                //������Ƶϵ��
			}
}
void wt53(int w,int h,int wsize,int hsize,int data[])
{
        int max=0,num255=0;
	    long i,j;
        int s[1000];
		for(i=0;i<h;i++){
			for(j=0;j<w;j++)
			    s[j]=data[i*wsize+j];                                //�Ƚ��� ��DWT
			wv1d(s,w);                
			for(j=0;j<w;j++)
				data[i*wsize+j]=s[j];                                //���ص͸�Ƶϵ��
		}
		for(i=0;i<w;i++){
			for(j=0;j<h;j++)
			    s[j]=data[j*wsize+i];                                //����� ��DWT
			wv1d(s,h);
			for(j=0;j<h;j++)
				data[j*wsize+i]=s[j];                                //������άDWT���
		}
		for(i=0;i<wsize*hsize;i++)
			DWT[i]=data[i];
}
void wt(int wv_level,int wwidth,int hheight,int coef[])              //wv_levelС���ֽ⼶��;
{
	int i;
	for (i=0;i<wv_level;i++)
		wt53(wwidth>>i,hheight>>i,wwidth,hheight,coef);
}

//С����任
void iwv1d(int s[],int ys)
{
	int j;
    int d1[500],s1[500];

	for(j=0;j<ys/2;j++){            //�ȷ���ߵ�Ƶ����s1,d1;
				s1[j]=s[j];
				d1[j]=s[j+ys/2];
			}
	    s[0]=s1[0]-((d1[0]+d1[0])/4);//s0
	for(j=1;j<ys/2;j++)
		s[2*j]=s1[j]-((d1[j-1]+d1[j])/4);//s(2...254)
    for(j=0;j<ys/2-1;j++)
		s[2*j+1]=d1[j]+((s[2*j]+s[2*j+2])/2);//s(1...253)
		s[ys-1]=d1[ys/2-1]+((s[ys-2]+s[ys-2])/2);//s255
}
void iwt53(int w,int h,int wsize,int hsize,int data[])
{
        int  i,j;
        int s[1000];

		for(i=0;i<w;i++){
			for(j=0;j<h;j++){
				s[j]=data[j*wsize+i];       //������DWT
			}
			iwv1d(s,h);
			for(j=0;j<h;j++)
			   data[j*wsize+i]=s[j];
		}
		for(i=0;i<h;i++){
			for(j=0;j<w;j++){
				s[j]=data[i*wsize+j];        //������DWT
			}
			iwv1d(s,w);
			for(j=0;j<w;j++)
			   data[i*wsize+j]=s[j];
		}
		for(i=0;i<height*width;i++)
			IDWT[i]=data[i];
}
void iwt(int wv_level,int width,int height,int coef[])
{
	int i;
	for (i=wv_level-1; i>=0; i--) 
		iwt53(width>>i,height>>i,width,height,coef);
}
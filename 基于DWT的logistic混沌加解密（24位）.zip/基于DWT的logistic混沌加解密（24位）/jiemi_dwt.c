#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <malloc.h>

#include"get_old_value.c"
#include"get_old_position.c"
#include"wave53.c"

void getBit(FILE *fpbmp);
void BmpWidthHeight(FILE* fpbmp);
void bmpHeaderPartLength(FILE* fpbmp);
void bmpoutput(FILE *fpout);
void get_initDWT(int step1[],int initDWT[]);

extern long height,width;
extern int IDWT[1024*1024];
long bitt,stride,maxbit;
unsigned int Offset=0;
int jiami_dwt[1024*1024*3],end[1024*1024*3];
int r[1024*1024],g[1024*1024],b[1024*1024];
int why[1024*1024];

void main()
{
	FILE *fpbmp;FILE *fpout;
	FILE *f_jiami;
	long i,j,z;unsigned char *fp_temp;
	int wv_level,*step1,*step2,*new_x,*new_y,*initDWT,*data;

    char name[30],name1[30],name2[30];
	char bmp[5]=".bmp";char txt[5]=".txt";
	char jiamibmp[40]="jiami_";char jiamitxt[40]="jiami_";char jiemibmp[40]="jiemi_";
	printf("������Ҫ���ܵ��ļ�����: ");
	gets(name);strcpy(name1,name);strcpy(name2,name);
    strcat(name,bmp);strcat(jiamibmp,name);
	strcat(name1,txt);strcat(jiamitxt,name1);
	strcat(name2,bmp);strcat(jiemibmp,name2);

	fpbmp=fopen(jiamibmp,"rb");//��ȡ ���� ͼ��;
	getBit(fpbmp);
    BmpWidthHeight(fpbmp);
    bmpHeaderPartLength(fpbmp);
	
    fpout=fopen(jiemibmp,"wb+");//���� ���� ͼ��;
	fp_temp=malloc(Offset);
    fseek(fpbmp,0L,SEEK_SET);fseek(fpout,0L,SEEK_SET);
	fread(fp_temp,1,Offset,fpbmp);fwrite(fp_temp,1,Offset,fpout);  
	fclose(fpbmp);free(fp_temp);

	f_jiami=fopen(jiamitxt,"rb");//��ȡ�������ݣ���������;
    for(i=0;i<height*stride;i++)
		fscanf(f_jiami,"%d",&jiami_dwt[i]);                     
	for(i=0;i<height*width;i++){
	    b[i]=jiami_dwt[i*3];
		g[i]=jiami_dwt[i*3+1];
		r[i]=jiami_dwt[i*3+2];
	}
    for(z=0;z<=2;z++)
	{
		data=malloc(sizeof(int)*width*height);
		step2=malloc(sizeof(int)*width*height);
		step1=malloc(sizeof(int)*width*height);
		initDWT=malloc(sizeof(int)*width*height);
		new_x=malloc(sizeof(int)*width);new_y=malloc(sizeof(int)*height);
	    switch(z)
		{
		case 0:
			printf("������B����������Կ\n");
			for(i=0;i<height*width;i++)
				data[i]=b[i];
			break;
		case 1:
			printf("������G����������Կ\n");
			for(i=0;i<height*width;i++)
			    data[i]=g[i];
			break;
		case 2:
			printf("������R����������Կ\n");
			for(i=0;i<height*width;i++)
			    data[i]=r[i];
			break;
		}//pass
		get_old_value(step2,data);free(data);//pass 

		get_old_position(new_x,new_y);
		for(i=0;i<height;i++){
			for(j=0;j<width;j++){
				step1[i*width+j]=step2[new_y[i]*width+new_x[j]];
			}
		}free(new_x);free(new_y);//pass

		get_initDWT(step1,initDWT);

		printf("������С���ع�����:");
        scanf("%d",&wv_level);
	    iwt(wv_level,width,height,initDWT);

        switch(z)
		{
		case 0:
		  for(i=0;i<height;i++){
		      for(j=0;j<width;j++){
			      b[(height-1-i)*width+j]=IDWT[i*width+j];
			  }
		  }break;
		 case 1:
           for(i=0;i<height;i++){
			   for(j=0;j<width;j++){
			       g[(height-1-i)*width+j]=IDWT[i*width+j];
			   }
		   }break;
         case 2:
           for(i=0;i<height;i++){
			   for(j=0;j<width;j++){
			       r[(height-1-i)*width+j]=IDWT[i*width+j];
			   }
		   }break;
		}free(step1);free(initDWT);
	}
	for(i=0;i<height*width;i++)
	{
	    end[i*3]=b[i];
		end[i*3+1]=g[i];
		end[i*3+2]=r[i];
	}
    bmpoutput(fpout);

    fclose(fpout);
	printf("������ɣ�����\n");
}

void get_initDWT(int step1[],int initDWT[])
{
	long i,max=0;int *temp;
	temp=malloc(sizeof(int)*height*width);
    for(i=0;i<height*width;i++)
	{
		temp[i]=step1[i];
		if(temp[i]>max)
		   max=temp[i];
	}printf("The max is %d\n",max);
	for(i=0;;i++){                                        //���С��ϵ������ֵ��������ƽ��
		if((max>pow(2,i))&&(max<pow(2,i+1)))
			break;
	}
	maxbit=i;
	printf("The maxbit is %d",maxbit);
	for(i=0;i<height*width;i++){
	    if((temp[i]&(int)pow(2,maxbit))==0)
			initDWT[i]=temp[i]&((int)pow(2,maxbit)-1);
		else
			initDWT[i]=(temp[i]&((int)pow(2,maxbit)-1))*(-1);		
	}
	free(temp);
}
void bmpoutput(FILE* fpout)
{
	long i;
    unsigned char *pixout=NULL;
    pixout=malloc(height*stride);
	for(i=0;i<height*stride;i++){
	    pixout[i]=end[i];
	}
	fwrite(pixout,1,height*stride,fpout);
/*	for(i=0;i<height;i++)
	    for(j=0;j<stride;j++)
			endend[height-1-i][j]=end_IDWT[i*stride+j];
    pixout=malloc(stride);
    fseek(fpout,Offset,SEEK_SET);              
    for(i=0;i<height;i++){
		for(j=0;j<stride;j++)
            pixout[j]=endend[i][j];
		fwrite(pixout,1,stride,fpout);
    }*/
}
void getBit(FILE *fpbmp)
{
	fseek(fpbmp,28L,SEEK_SET);
	fread(&bitt,1,2,fpbmp);
}
void BmpWidthHeight(FILE* fpbmp)
{
     fseek(fpbmp,18L,SEEK_SET);
     fread(&width,1,4,fpbmp);
     fseek(fpbmp,22L,SEEK_SET);
     fread(&height,1,4,fpbmp);
	 stride=(bitt*width+31)/32*4;
}
void bmpHeaderPartLength(FILE* fpbmp)
{
     fseek(fpbmp,10L,SEEK_SET);
     fread(&Offset,1,4,fpbmp);  
}

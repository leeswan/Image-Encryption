typedef struct Stu{
    double xn;
	int position;
}stu;
stu sz[1024];

long width,height;

int cmp(const void *a,const void *b)
{
    stu c=*(stu*)a;
    stu d=*(stu*)b; 
    return c.xn>d.xn?1:-1;
}
double creat()                  
{
	double key1;
	scanf("%lf",&key1);
	return key1;
}
void yiwei_logistic_position(long len,double key)
{
    double x,r=3.99;
	long i;
	x = key;
    for(i=0;i<len;i++){
		x=r*x*(1.0-x);
		sz[i].xn=x;
	}
}
void get_new_position(int new_x[],int new_y[])
{
     int i,z;
     for(z=0;z<2;z++){
		 switch(z){
		 case 0:{
			 printf("������ˮƽ����λ��������Կ:");
			 yiwei_logistic_position(width,creat());
			 for(i=0;i<width;i++)
		         sz[i].position=i;
	         qsort(sz,width,sizeof(sz[0]),cmp);
			 for(i=0;i<width;i++)
				 new_x[i]=sz[i].position;
				}break;
		 case 1:{
			 printf("�����봹ֱ����λ��������Կ:");
			 yiwei_logistic_position(height,creat());
			 for(i=0;i<height;i++)
		         sz[i].position=i;
	         qsort(sz,height,sizeof(sz[0]),cmp);
			 for(i=0;i<height;i++)
				 new_y[i]=sz[i].position;
				}break;
		 }
	 }	     
}



#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <malloc.h>

void getBit(FILE *fpbmp);
void BmpWidthHeight(FILE* fpbmp);
void bmpHeaderPartLength(FILE* fpbmp);
void bmpoutput(FILE *fpout);
int iwv_level();
void creat_m();
void creat_xn(unsigned char key1[]);
void get_initDWT(int rgb[]);
void iwv1d(int s[],int ys);
void iwt53(int w,int h,int wsize,int hsize,int data[]);
void iwt(int wv_level,int width,int height,int coef[]);

long height,width,bitt,stride,maxbit;
unsigned int Offset=0;
int jiami_dwt[1024*1024*3],initDWT[1024*1024],IDWT[1024*1024],endend[1024][1024*3];
int wei_DWT[1024*1024],absDWT[1024*1024],end_IDWT[1024*1024*3];
int r[1024*1024],g[1024*1024],b[1024*1024];
unsigned char init[20],update[20],key[1024*1024*72],xn_m[1024*1024],xnn[1024*1024*9];

void main()
{
	FILE *fpbmp;FILE *fpout;
	FILE *f_jiami;
	FILE *f_jiemi;
	long i,z;unsigned char *fp_temp;

    char name[30],name1[30],name2[30],name3[30];char bmp[5]=".bmp";char txt[5]=".txt";
	char jiamibmp[40]="jiami_";char jiamitxt[40]="jiami_";char jiemibmp[40]="jiemi_";char jiemitxt[40]="jiemi_";
	printf("������Ҫ���ܵ��ļ�����: ");
	gets(name);strcpy(name1,name);strcpy(name2,name);strcpy(name3,name);
    strcat(name,bmp);strcat(jiamibmp,name);
	strcat(name3,txt);strcat(jiamitxt,name3);
	strcat(name1,bmp);strcat(jiemibmp,name1);
	strcat(name2,txt);strcat(jiemitxt,name2);

	fpbmp=fopen(jiamibmp,"rb"); //��ȡ���ܵ�DWTͼ��;
	getBit(fpbmp);
    BmpWidthHeight(fpbmp);
    bmpHeaderPartLength(fpbmp);
	stride=(bitt*width+31)/32*4;

    fpout=fopen(jiemibmp,"wb+"); //��������ͼ��;
	fp_temp=malloc(Offset);
    fseek(fpbmp,0L,SEEK_SET);fseek(fpout,0L,SEEK_SET);
	fread(fp_temp,1,Offset,fpbmp);fwrite(fp_temp,1,Offset,fpout);  
	fclose(fpbmp);

	f_jiami=fopen(jiamitxt,"rb");
    for(i=0;i<height*stride;i++){
		fscanf(f_jiami,"%d",&jiami_dwt[i]);      //��ȡ���ܺ��DWTϵ������������;
	}
	for(i=0;i<height*width;i++){
	    b[i]=jiami_dwt[i*3];
		g[i]=jiami_dwt[i*3+1];
		r[i]=jiami_dwt[i*3+2];
	}
    for(z=0;z<=2;z++)
	{
	    switch(z)
		{
		case 0:
			printf("������B��������m���г�ʼ״ֵ̬��");
			creat_m();
			get_initDWT(b);
			iwt(iwv_level(),width,height,initDWT);
			for(i=0;i<height*width;i++){
			    b[i]=IDWT[i];
			}break;
		case 1:
			printf("������G��������m���г�ʼ״ֵ̬��");
			creat_m();
            get_initDWT(g);
			iwt(iwv_level(),width,height,initDWT);
			for(i=0;i<height*width;i++){
			    g[i]=IDWT[i];
			}break;
		case 2:
			printf("������R��������m���г�ʼ״ֵ̬��");
			creat_m();
            get_initDWT(r);
			iwt(iwv_level(),width,height,initDWT);
			for(i=0;i<height*width;i++){
			    r[i]=IDWT[i];
			}break;
		}
	}
	for(i=0;i<height*width;i++)
	{
	    end_IDWT[i*3]=b[i];
		end_IDWT[i*3+1]=g[i];
		end_IDWT[i*3+2]=r[i];
	}
    bmpoutput(fpout);

	f_jiemi=fopen(jiemitxt,"w+");
	for(i=0;i<height*stride;i++){
	    fprintf(f_jiemi,"%-4d",end_IDWT[i]);
	}fclose(fpout);
	printf("������ɣ�����\n");
}
int iwv_level()
{
    int iwv_level;
	printf("�������ع�����: ");
	scanf("%d",&iwv_level);
	return iwv_level;
}
void creat_m()
{
    unsigned long i;
	long length;
	unsigned char flag;
//	printf("������20bit����m���г�ʼ״ֵ̬:");//��ʼ״̬����Ϊ��Կ
	for(i=0;i<20;i++)
	    scanf("%d",&init[i]);//�����ʼ״̬;
	for(length=0;length<height*width*64;length++)
	{
		flag=init[16]^init[19];
        for(i=0;i<19;i++){
	     	update[i+1]=init[i];
		}
		update[0]=flag;
		key[length]=init[19];//ÿ�δ�ĩβ���һλ�����͵�key���飻
//		printf("%2d",key[length]);
		for(i=0;i<20;i++){
		    init[i]=update[i];
		}
	}
	creat_xn(key);
}
void creat_xn(unsigned char key1[])
{
    long i,j;
	for(i=0;i<height*width*8;i++)
	    xnn[i]=key1[i*8];
	for(j=0;j<height*width;j++){
		xn_m[j]=0;
		for(i=0;i<8;i++){
		    xn_m[j]=(xn_m[j]<<1)|(xnn[i*8+j]);
		}
	}
}
void get_initDWT(int rgb[])
{
	long i,max=0;
    for(i=0;i<height*width;i++){
		wei_DWT[i]=(rgb[i])^(xn_m[i]);
		if(wei_DWT[i]>max)
			max=wei_DWT[i];
	}
	for(i=0;;i++){
		if((max>pow(2,i))&&(max<pow(2,i+1))){
		    maxbit=i;
			break;
		}
	}
	for(i=0;i<height*width;i++){
	    if((wei_DWT[i]&(int)pow(2,maxbit))==0)
			initDWT[i]=wei_DWT[i]&((int)pow(2,maxbit)-1);
		else
			initDWT[i]=(wei_DWT[i]&((int)pow(2,maxbit)-1))*(-1);		
//		printf("%-5d",initDWT[i]);
	}
}
void bmpoutput(FILE* fpout)
{
	long i,j;
    unsigned char *pixout=NULL;

	for(i=0;i<height;i++)
	{
	    for(j=0;j<stride;j++)
			endend[height-1-i][j]=end_IDWT[i*stride+j];
	}
    pixout=malloc(stride);
    fseek(fpout,Offset,SEEK_SET);              
    for(i=0;i<height;i++)
    {
		for(j=0;j<stride;j++)
            pixout[j]=endend[i][j];
		fwrite(pixout,1,stride,fpout);
    }
}
void getBit(FILE *fpbmp)
{
	fseek(fpbmp,28L,SEEK_SET);
	fread(&bitt,1,2,fpbmp);
//	printf("bit of pix is %d\n",bitt);
}
void BmpWidthHeight(FILE* fpbmp)
{
     fseek(fpbmp,18L,SEEK_SET);
     fread(&width,1,4,fpbmp);
     fseek(fpbmp,22L,SEEK_SET);
     fread(&height,1,4,fpbmp);
//     printf("The Width of the bmp file is %d\n",width);
//     printf("The Height of the bmp file is %d\n",height);
}
void bmpHeaderPartLength(FILE* fpbmp)
{
     fseek(fpbmp,10L,SEEK_SET);
     fread(&Offset,1,4,fpbmp);  
//     printf("The Header Part is of length %d\n",Offset);
}
void iwv1d(int s[],int ys)
{
	int j;
    int d1[500],s1[500];

	for(j=0;j<ys/2;j++){            //�ȷ���ߵ�Ƶ����s1,d1;
				s1[j]=s[j];
				d1[j]=s[j+ys/2];
			}
	    s[0]=s1[0]-((d1[0]+d1[0])/4);//s0
	for(j=1;j<ys/2;j++)
		s[2*j]=s1[j]-((d1[j-1]+d1[j])/4);//s(2...254)
    for(j=0;j<ys/2-1;j++)
		s[2*j+1]=d1[j]+((s[2*j]+s[2*j+2])/2);//s(1...253)
		s[ys-1]=d1[ys/2-1]+((s[ys-2]+s[ys-2])/2);//s255
}
void iwt53(int w,int h,int wsize,int hsize,int data[])
{
        int  i,j;
        int s[1000];

		for(i=0;i<w;i++){
			for(j=0;j<h;j++){
				s[j]=data[j*wsize+i];       //������DWT
			}
			iwv1d(s,h);
			for(j=0;j<h;j++)
			   data[j*wsize+i]=s[j];
		}
		for(i=0;i<h;i++){
			for(j=0;j<w;j++){
				s[j]=data[i*wsize+j];        //������DWT
			}
			iwv1d(s,w);
			for(j=0;j<w;j++)
			   data[i*wsize+j]=s[j];
		}
		for(i=0;i<height*width;i++)
			IDWT[i]=data[i];
}
void iwt(int wv_level,int width,int height,int coef[])
{
	int i;
	for (i=wv_level-1; i>=0; i--) 
		iwt53(width>>i,height>>i,width,height,coef);
}
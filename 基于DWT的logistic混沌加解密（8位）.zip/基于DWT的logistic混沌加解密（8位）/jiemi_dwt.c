#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <malloc.h>

void BmpWidthHeight(FILE* fpbmp);
void bmpHeaderPartLength(FILE* fpbmp);
//void bmpDataPart(FILE* fpbmp);
int iwv_level();
double inputkey();
void get_maxbit(int jiami_dwt[]);
void yiwei_logistic(long len,double key);
void get_initDWT();
void iwv1d(int s[],int ys);
void iwt53(int w,int h,int wsize,int hsize,int data[]);
void iwt(int wv_level,int width,int height,int coef[]);
void bmpoutput(FILE *fpout);


long height,width,maxbit;
unsigned int Offset=0;
int jiami_dwt[1000*1000],xn[1000*1000],initDWT[1000*1000],IDWT[1000*1000],endend[1024][1024];
int xnn[1000*1000*9],wei_DWT[1000*1000],absDWT[1000*1000];

void main()
{
	FILE *fpbmp;FILE *fpout;
	FILE *f_jiami;
	FILE *f_jiemi;
	long i;unsigned char *fp_temp;

    char name[30],name1[30],name2[30],name3[30];char bmp[5]=".bmp";char txt[5]=".txt";
	char jiamibmp[40]="jiami_";char jiamitxt[40]="jiami_";char jiemibmp[40]="jiemi_";char jiemitxt[40]="jiemi_";
	printf("������Ҫ���ܵ��ļ�����: ");
	gets(name);strcpy(name1,name);strcpy(name2,name);strcpy(name3,name);
    strcat(name,bmp);strcat(jiamibmp,name);
	strcat(name3,txt);strcat(jiamitxt,name3);
	strcat(name1,bmp);strcat(jiemibmp,name1);
	strcat(name2,txt);strcat(jiemitxt,name2);

	fpbmp=fopen(jiamibmp,"rb");                                 //��ȡ���ܵ�DWTͼ��;
    BmpWidthHeight(fpbmp);
    bmpHeaderPartLength(fpbmp);

    fpout=fopen(jiemibmp,"wb+");                                //��������ͼ��;
	fp_temp=malloc(Offset);
    fseek(fpbmp,0L,SEEK_SET);fseek(fpout,0L,SEEK_SET);
	fread(fp_temp,1,Offset,fpbmp);fwrite(fp_temp,1,Offset,fpout);
	fclose(fpbmp);

	f_jiami=fopen(jiamitxt,"rb");                               //��ȡ���ܺ��DWTϵ��;
    for(i=0;i<height*width;i++)
		fscanf(f_jiami,"%d",&jiami_dwt[i]);

    yiwei_logistic(height*width*8,inputkey());

	get_initDWT();

	iwt(iwv_level(),width,height,initDWT);

    bmpoutput(fpout);

	f_jiemi=fopen(jiemitxt,"w+");
	for(i=0;i<height*width;i++){
	    fprintf(f_jiemi,"%-4d",IDWT[i]);
	}fclose(fpout);
	printf("������ɣ�����\n");
}





void get_maxbit(int jiami_dwt[])
{
    long i,max=0;
	for(i=0;i<height*width;i++){
	    if(jiami_dwt[i]>max)
			max=jiami_dwt[i];
	}
	for(i=0;;i++){                                        //���С��ϵ������ֵ��������ƽ��
		if((max>pow(2,i))&&(max<pow(2,i+1))){
		    maxbit=i;
			break;
		}
	}
}

int iwv_level()
{
    int iwv_level;
	printf("�������ع�����: ");
	scanf("%d",&iwv_level);
	return iwv_level;
}
double inputkey()
{
    double key;
	printf("��������Կ: ");
	scanf("%lf",&key);
	return key;
}
void yiwei_logistic(long len,double key)
{
    double x,r=3.99;
	long i,j,k=0;int t;
	x = key;
//	printf("%.10lf\n",x);
    for(i=0;i<len;i++){
		x=r*x*(1.0-x);           //����
		t=(int)(x*256);          //ӳ����0-255
		t=t&128;                 //ȡ��7λ
		if(!t)
			xnn[i]= 0;
		else 
			xnn[i]= 1;}
    for(i=0;i<height*width;i++){
		for(j=0;j<8;j++){
		    xn[i]=(xn[i]<<1)|xnn[i*8+j];
		}
/*	    for(j=k;j<height*width*8;){
		    xn[i]=(xnn[j]<<8)|(xnn[j+1]<<7)|(xnn[j+2]<<6)|
				    (xnn[j+3]<<5)|(xnn[j+4]<<4)|(xnn[j+5]<<3)|
					(xnn[j+6]<<2)|(xnn[j+7]<<1)|(xnn[j+8]);break;
		}
		k+=4;*/
	}
/*	for(i=0;i<height*width;i++)
		printf("%-4d",xn[i]);*/   
}

void get_initDWT()
{
	long i;
    for(i=0;i<height*width;i++){
		wei_DWT[i]=(jiami_dwt[i])^(xn[i]);
//		printf("%-4d",wei_DWT[i]);
	}
	get_maxbit(wei_DWT);
	for(i=0;i<height*width;i++){
	    if((wei_DWT[i]&(int)pow(2,maxbit))==0)
			initDWT[i]=wei_DWT[i]&((int)pow(2,maxbit)-1);
		else
			initDWT[i]=(wei_DWT[i]&((int)pow(2,maxbit)-1))*(-1);		
//		printf("%-4d",initDWT[i]);
	}
}

void bmpDataPart(FILE* fpbmp)
{
    long i;
    unsigned char *pix=NULL;
    pix=malloc(height*width);                      //���������ֽ����Ĵ�С�ڴ�ռ�
    fseek(fpbmp,1078L,SEEK_SET);                   //ԭͼ���ļ�ָ�붨λ������������ʼ�ֽڴ�
    fread(pix,1,height*width,fpbmp);               //����һ������ֵ��ע���ͼƬ������λ��Ϊ8��widthΪ4��������
    for(i=0;i<height*width;i++)                         //��ˣ�stride=width
        jiami_dwt[i]=pix[i];
}
void bmpoutput(FILE* fpout)
{
	long i,j;
    unsigned char *pixout=NULL;
	for(i=0;i<height;i++)
	{
	    for(j=0;j<width;j++)
			endend[height-1-i][j]=IDWT[i*width+j];
	}
    pixout=malloc(width);
    fseek(fpout,Offset,SEEK_SET);              
    for(i=0;i<height;i++)
    {
		for(j=0;j<width;j++)
            pixout[j]=endend[i][j];
		fwrite(pixout,1,width,fpout);
    }
}
void BmpWidthHeight(FILE* fpbmp)
{
     fseek(fpbmp,18L,SEEK_SET);
     fread(&width,1,4,fpbmp);
     fseek(fpbmp,22L,SEEK_SET);
     fread(&height,1,4,fpbmp);
//     printf("The Width of the bmp file is %d\n",width);
//     printf("The Height of the bmp file is %d\n",height);
}
void bmpHeaderPartLength(FILE* fpbmp)
{
     fseek(fpbmp,10L,SEEK_SET);
     fread(&Offset,1,4,fpbmp);  
//     printf("The Header Part is of length %d\n",Offset);
}
void iwv1d(int s[],int ys)
{
	int j;
    int d1[500],s1[500];

	for(j=0;j<ys/2;j++){            //�ȷ���ߵ�Ƶ����s1,d1;
				s1[j]=s[j];
				d1[j]=s[j+ys/2];
			}
	    s[0]=s1[0]-((d1[0]+d1[0])/4);//s0
	for(j=1;j<ys/2;j++)
		s[2*j]=s1[j]-((d1[j-1]+d1[j])/4);//s(2...254)
    for(j=0;j<ys/2-1;j++)
		s[2*j+1]=d1[j]+((s[2*j]+s[2*j+2])/2);//s(1...253)
		s[ys-1]=d1[ys/2-1]+((s[ys-2]+s[ys-2])/2);//s255
}
void iwt53(int w,int h,int wsize,int hsize,int data[])
{
        int  i,j;
        int s[1000];

		for(i=0;i<w;i++){
			for(j=0;j<h;j++){
				s[j]=data[j*wsize+i];       //������DWT
		//		if(i<w/2 && j<h/2) s[j]/=2;
		//		else if(i>=w/2 && j>=h/2) s[j]*=2;
			}
			iwv1d(s,h);
			for(j=0;j<h;j++)
			   data[j*wsize+i]=s[j];
		}
		for(i=0;i<h;i++){
			for(j=0;j<w;j++){
				s[j]=data[i*wsize+j];        //������DWT
			}
			iwv1d(s,w);
			for(j=0;j<w;j++)
			   data[i*wsize+j]=s[j];
		}
		for(i=0;i<height*width;i++)
			IDWT[i]=data[i];
}
void iwt(int wv_level,int width,int height,int coef[])
{
	int i;
	for (i=wv_level-1; i>=0; i--) 
		iwt53(width>>i,height>>i,width,height,coef);
}
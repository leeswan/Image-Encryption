#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string.h>
#include <malloc.h>

void BmpWidthHeight(FILE* fpbmp);
void bmpHeaderPartLength(FILE* fpbmp);
int iwv_level();
void creat_m();
void creat_xn(unsigned char key1[]);
void get_initDWT();
void iwv1d(int s[],int ys);
void iwt53(int w,int h,int wsize,int hsize,int data[]);
void iwt(int wv_level,int width,int height,int coef[]);
void bmpoutput(FILE *fpout);


long height,width,maxbit;
unsigned int Offset=0;
int jiami_dwt[1000*1000],wei_dwt[1024*1024],init_dwt[1024*1024],IDWT[1000*1000],endend[1000][1000];
unsigned char init[20],update[20];
unsigned char xnn[1024*1024*9],key[1024*1024*72],xn_m[1024*1024];

void main()
{
	FILE *fpbmp;FILE *fpout;
	FILE *f_jiami;
	FILE *f_jiemi;
	long i;unsigned char *fp_temp;

    char name[30],name1[30],name2[30],name3[30];char bmp[5]=".bmp";char txt[5]=".txt";
	char jiamibmp[40]="jiami_";char jiamitxt[40]="jiami_";char jiemibmp[40]="jiemi_";char jiemitxt[40]="jiemi_";
	printf("������Ҫ���ܵ��ļ�����: ");
	gets(name);strcpy(name1,name);strcpy(name2,name);strcpy(name3,name);
    strcat(name,bmp);strcat(jiamibmp,name);
	strcat(name3,txt);strcat(jiamitxt,name3);
	strcat(name1,bmp);strcat(jiemibmp,name1);
	strcat(name2,txt);strcat(jiemitxt,name2);

	fpbmp=fopen(jiamibmp/*"jiami_dwt_Miss.bmp"*/,"rb"); //��ȡ���ܵ�DWTͼ��;

    BmpWidthHeight(fpbmp);
    bmpHeaderPartLength(fpbmp);

    fpout=fopen(jiemibmp/*"jiemi_dwt_Miss.bmp"*/,"wb+"); //��������ͼ��;
	fp_temp=malloc(Offset);
    fseek(fpbmp,0L,SEEK_SET);fseek(fpout,0L,SEEK_SET);
	fread(fp_temp,1,Offset,fpbmp);fwrite(fp_temp,1,Offset,fpout);
    
	fclose(fpbmp);
	f_jiami=fopen(jiamitxt,"rb"); //��ȡ���ܺ��DWTϵ��;
    for(i=0;i<height*width;i++){
		fscanf(f_jiami,"%d",&jiami_dwt[i]);}//ok*/

    creat_m();

	get_initDWT();

	iwt(iwv_level(),width,height,init_dwt);

    bmpoutput(fpout);

	f_jiemi=fopen(jiemitxt/*"jiemi_Miss.txt"*/,"w+");
	for(i=0;i<height*width;i++){
	    fprintf(f_jiemi,"%-4d",IDWT[i]);
	}fclose(fpout);
	printf("������ɣ�����\n");
}




void get_maxbit(int jiami_dwt[])
{
    long i,max=0;
	for(i=0;i<height*width;i++){
	    if(jiami_dwt[i]>max)
			max=jiami_dwt[i];
	}
	for(i=0;;i++){                                        //���С��ϵ������ֵ��������ƽ��
		if((max>pow(2,i))&&(max<pow(2,i+1))){
		    maxbit=i;
			break;
		}
	}
}
int iwv_level()
{
    int iwv_level;
	printf("�������ع�����: ");
	scanf("%d",&iwv_level);
	return iwv_level;
}
void creat_m()
{
    long i;
	long length;
	int flag;
	printf("������20bit����m���г�ʼ״ֵ̬:");
	for(i=0;i<20;i++)
	    scanf("%d",&init[i]);//�����ʼ״̬;
	for(length=0;length<height*width*64;length++)
	{
		flag=init[16]^init[19];
        for(i=0;i<19;i++){
	     	update[i+1]=init[i];
		}
		update[0]=flag;
		key[length]=init[19];//ÿ�δ�ĩβ���һλ�����͵�key���飻
//		printf("%2d",key[length]);
		for(i=0;i<20;i++){
		    init[i]=update[i];
		}
	}
	creat_xn(key);
}
void creat_xn(unsigned char key1[])
{
    long i,j;
	for(i=0;i<height*width*8;i++)
	    xnn[i]=key1[i*8];
	for(j=0;j<height*width;j++){
		for(i=0;i<8;i++)
		    xn_m[j]=(xn_m[j]<<1)|xnn[j*8+i];
	}
}
void get_initDWT()
{
	long i;
    for(i=0;i<height*width;i++){
		wei_dwt[i]=(jiami_dwt[i])^(xn_m[i]);
//		printf("%-4d",wei_DWT[i]);
	}
	get_maxbit(wei_dwt);
	for(i=0;i<height*width;i++){
	    if((wei_dwt[i]&(int)pow(2,maxbit))==0)
			init_dwt[i]=wei_dwt[i]&((int)pow(2,maxbit)-1);
		else
			init_dwt[i]=(wei_dwt[i]&((int)pow(2,maxbit)-1))*(-1);		
//		printf("%-4d",init_dwt[i]);
	}
}

void bmpoutput(FILE* fpout)
{
	long i,j;
    unsigned char *pixout=NULL;

	for(i=0;i<height;i++)
	{
	    for(j=0;j<width;j++)
			endend[height-1-i][j]=IDWT[i*width+j];
	}
    pixout=malloc(width);
    fseek(fpout,Offset,SEEK_SET);              
    for(i=0;i<height;i++)
    {
		for(j=0;j<width;j++)
            pixout[j]=endend[i][j];
		fwrite(pixout,1,width,fpout);
    }
}
void BmpWidthHeight(FILE* fpbmp)
{
     fseek(fpbmp,18L,SEEK_SET);
     fread(&width,1,4,fpbmp);
     fseek(fpbmp,22L,SEEK_SET);
     fread(&height,1,4,fpbmp);
//     printf("The Width of the bmp file is %d\n",width);
//     printf("The Height of the bmp file is %d\n",height);
}
void bmpHeaderPartLength(FILE* fpbmp)
{
     fseek(fpbmp,10L,SEEK_SET);
     fread(&Offset,1,4,fpbmp);  
//     printf("The Header Part is of length %d\n",Offset);
}
void iwv1d(int s[],int ys)
{
	int j;
    int d1[500],s1[500];

	for(j=0;j<ys/2;j++){            //�ȷ���ߵ�Ƶ����s1,d1;
				s1[j]=s[j];
				d1[j]=s[j+ys/2];
			}
	    s[0]=s1[0]-((d1[0]+d1[0])/4);//s0
	for(j=1;j<ys/2;j++)
		s[2*j]=s1[j]-((d1[j-1]+d1[j])/4);//s(2...254)
    for(j=0;j<ys/2-1;j++)
		s[2*j+1]=d1[j]+((s[2*j]+s[2*j+2])/2);//s(1...253)
		s[ys-1]=d1[ys/2-1]+((s[ys-2]+s[ys-2])/2);//s255
}
void iwt53(int w,int h,int wsize,int hsize,int data[])
{
        int  i,j;
        int s[1000];

		for(i=0;i<w;i++){
			for(j=0;j<h;j++){
				s[j]=data[j*wsize+i];       //������DWT
		//		if(i<w/2 && j<h/2) s[j]/=2;
		//		else if(i>=w/2 && j>=h/2) s[j]*=2;
			}
			iwv1d(s,h);
			for(j=0;j<h;j++)
			   data[j*wsize+i]=s[j];
		}
		for(i=0;i<h;i++){
			for(j=0;j<w;j++){
				s[j]=data[i*wsize+j];        //������DWT
			}
			iwv1d(s,w);
			for(j=0;j<w;j++)
			   data[i*wsize+j]=s[j];
		}
		for(i=0;i<height*width;i++){
			IDWT[i]=data[i];
//            printf("%-5d",IDWT[i]);
		}
}
void iwt(int wv_level,int width,int height,int coef[])
{
	int i;
	for (i=wv_level-1; i>=0; i--) 
		iwt53(width>>i,height>>i,width,height,coef);
}
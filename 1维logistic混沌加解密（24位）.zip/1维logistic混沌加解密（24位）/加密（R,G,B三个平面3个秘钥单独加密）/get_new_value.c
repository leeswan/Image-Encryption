long width,height;

/*double creat()                  
{
	double key1;
	scanf("%lf",&key1);
	return key1;
}*/
void yiwei_logistic_value(long len,double key,unsigned char xn[])
{
    double x,r=3.99;long i,j;int t;unsigned char *xnn;
	x = key;
	xnn=malloc(sizeof(unsigned char)*len);
    for(i=0;i<len;i++){
		x=r*x*(1.0-x);           
		t=(int)(x*256);      
		t=t&128;               
		if(!t)
			xnn[i]= 0;
		else 
			xnn[i]= 1;
	}
	for(i=0;i<height*width;i++){
		xn[i]=0;
        for(j=0;j<8;j++){
		    xn[i]=(xn[i]<<1)|xnn[i*8+j];
		}	    
	}
	free(xnn);
}
void get_new_value(unsigned char step1[],unsigned char final[])
{
	long i;unsigned char *xn;
	xn=malloc(sizeof(unsigned char)*height*width);
	printf("����������ֵ������Կ:");
    yiwei_logistic_value(height*width*8,creat(),xn);
    for(i=0;i<height*width;i++)
	    final[i]=(xn[i])^(step1[i]);
	free(xn);
}


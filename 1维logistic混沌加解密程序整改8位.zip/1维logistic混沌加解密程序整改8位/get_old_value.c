long width,height;

/*double inputkey()
{
    double key;
	scanf("%lf",&key);
	return key;
}*/
void yiwei_logistic_value(long len,double key,unsigned char xn[])
{
    double x,r=3.99;long i,j;int t;unsigned char *xnn;
	x = key;
	xnn=malloc(sizeof(unsigned char)*len);
    for(i=0;i<len;i++)
	{
		x=r*x*(1.0-x);           //����
		t=(int)(x*256);        //ӳ����0-255
		t=t&128;               //ȡ��7λ
		if(!t)
			xnn[i]= 0;
		else 
			xnn[i]= 1;
	}
	for(i=0;i<height*width;i++){
        for(j=0;j<8;j++){
		    xn[i]=(xn[i]<<1)|xnn[i*8+j];
		}	    
	}
	free(xnn);
}
void get_old_value(unsigned char step2[],unsigned char a[])
{
    long i;unsigned char *xn;
	xn=malloc(sizeof(unsigned char)*height*width);
	printf("����������ֵ���ҽ�Կ:");
	yiwei_logistic_value(height*width*8,inputkey(),xn);
	for(i=0;i<height*width;i++)
		step2[i]=(xn[i])^(a[i]);
}
